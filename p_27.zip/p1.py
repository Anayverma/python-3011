# Ques 1) Write a program in python to create a matrix of size 3X3 with variable name A.
l=[]
for i in range(0,3):
    c=[]
    for j in range(0,3):
        c.append(j)
    l.append(c)
print(l)