# Demonstrate the use of Data types/structures (List)
my_list=[]
my_list.append(1)
my_list.append(2)
my_list.append(3)
 
print("Element of the list are => ",my_list)