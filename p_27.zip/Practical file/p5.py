# Define a function named greet
def greetings_fun():
    print("Hello World")

# Call the greet function
greetings_fun()