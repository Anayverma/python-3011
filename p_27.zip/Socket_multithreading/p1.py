# You can also find the IP using python:

import socket
ip = socket.gethostbyname('www.google.com')
print (ip)