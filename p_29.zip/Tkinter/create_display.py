import tkinter 
mybox=tkinter.Tk()
mybox.geometry('400x400')
mybox.configure(bg='red')
mybox.title("First")
tkinter.mainloop()
